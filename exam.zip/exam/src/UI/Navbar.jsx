import React from "react"; 
import "./Navbar.css";

const Navbar = () => {
  return (
    <div className="navbar_wrap">
      
      <h2>Test</h2>
    
    </div>
  );
};

export default Navbar;
