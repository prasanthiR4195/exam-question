import React from 'react'
import Button from '../UI/Button'
import './Result.css'

const Result = () => {
  const handleSubmit =(e)=>{
    e.preventDefault();
    alert("are you sure you want to submit")
  }
  return (
    <div className='Result_wrap'>
        <h1>Results</h1>
        <p>Selected answers</p>
      <div className='result_box'>
      <ul>
          <li>Kaakka</li>
          <li>Poocha</li>
          <li>Olakka</li>
        </ul>
        <Button onClick={handleSubmit}>Submit</Button>
      </div>
    </div>
  )
}

export default Result