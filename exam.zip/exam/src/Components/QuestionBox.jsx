import React from "react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Button from "../UI/Button";
import "./QuestionBox.css";

const QuestionBox = ({ currentQues, setcurrentQues, questions }) => {
  const [selected, setSelected] = useState();
  const [error, setError] = useState(false);
  const navigate = useNavigate();

  const handleNext = () => {
    if (currentQues > 6) {
      navigate("/result");
    } else if (selected) {
      setcurrentQues(currentQues + 1);
      console.log(currentQues + 1);
      setSelected();
    } else { 
      setError(true);
    }
  };
  const handlePrev = () => {
    if (currentQues === 0) {
      navigate("/");
    } else {
      setcurrentQues(currentQues - 1);
    }
  };



  function onChangeValue(event) {
    setSelected(event.target.value);
  }

  const questionItem =  questions.questions.map((item,index)=>{
    if(item.questiontype ==='Textarea' ){
      return ( 
       <p>{item.questionid}</p>
      )
    }else if(item.questiontype ==='Date'  ){
      return ( 
        <p>{item.questionid}</p>
      )
      
    }else if(item.questiontype ==='Radio' ){
      return ( 
        questions.questions[currentQues].questionoption.map((option, index) => {
          return (
            <div className="options" onChange={onChangeValue} key={index}>
              <input type="radio" id={option.optionid} name="optionname" />{" "}
              <label>{option.optionvalue}</label>
            </div>
          );
        })
      )
    }else if(item.questiontype ==='Checkbox'  ){
      return ( 
        <p>{item.questionid}</p>
      )
    }
  })


  


 

  return (
    <div>
      <h3>Question {currentQues + 1}</h3>
      <h4>{questions.questions[currentQues].question}</h4>

      {questionItem}
      
      {/* {questions.questions[currentQues].questionoption.map((option, index) => {
        return (
          <div className="options" onChange={onChangeValue} key={index}>
            <input type="radio" id={option.optionid} name="optionname" />{" "}
            <label>{option.optionvalue}</label>
          </div>
        );
      })} */}

      
      {error ? <p>Please select an option</p> : ""}
      <div className="prev_nex_btn">
        <Button onClick={handlePrev}>Previous</Button>
        <Button onClick={handleNext}>Next</Button>
      </div>
    </div>
  );
};

export default QuestionBox;
