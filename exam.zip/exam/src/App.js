import "./App.css";
import Card from "./UI/Card";
import Navbar from "./UI/Navbar";
import Question from "./Components/Question";
import Home from "./Components/Home";
import { BrowserRouter, Route, Routes  } from "react-router-dom";
import Result from "./Components/Result";


function App() {
  return (
    <BrowserRouter>
      <div className="App">
        <Navbar /> 

        <Routes>
          <Route path="/"  element={<Home />} exact/>
          <Route path="/question"  element={<Question/>} />
          <Route path="/result"  element={<Result/>} />
        </Routes>
 
      </div>
    </BrowserRouter>
  );
}

export default App;
